package Pdf0;

/*
2 - Crea la variable nombre y asígnale tu nombre completo. Muestra su valor por pantalla de tal
forma que el resultado del programa sea el mismo que en el ejercicio 1 del capítulo 1.
*/

class Ejercicio2 {
    public static void main(String[] args) {
        String nombre = "Alejandro Díaz Barea";

        System.out.println(nombre);
    }
}