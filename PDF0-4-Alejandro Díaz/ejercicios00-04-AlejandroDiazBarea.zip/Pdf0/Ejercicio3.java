package Pdf0;

/*
3 - Crea las variables nombre, direccion y telefono y asígnale los valores corres- pondientes. Muestra
los valores de esas variables por pantalla de tal forma que el resultado del programa sea el mismo
que en el ejercicio 2.
 */
public class Ejercicio3 {
    public static void main(String[] args){
        String nombre = "Alejandro";
        String direccion = "Cadiz";
        int telefono = 92748937;

        System.out.println(nombre);
        System.out.println(direccion);
        System.out.println(telefono);
    }
}
